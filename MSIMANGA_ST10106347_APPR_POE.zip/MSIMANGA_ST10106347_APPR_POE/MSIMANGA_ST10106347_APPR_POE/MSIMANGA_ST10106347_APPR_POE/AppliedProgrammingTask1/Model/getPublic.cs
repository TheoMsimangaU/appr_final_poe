﻿namespace AppliedProgrammingTask1.Model
{
    public class getPublic
    {
        //d.STARTING_DATE, d.ENDING_DATE,d.DISASTER_DESCRIPTION, d.LOCATION, d.AID, ai.item, am.moneys
        public string startDate {  get; set; }
        public string endDate { get; set; }
        public string description { get; set; }

        public string location { get; set; }

        public string aid { get; set; }

        public string item { get; set; }

        public string money { get; set; }
    }
}
