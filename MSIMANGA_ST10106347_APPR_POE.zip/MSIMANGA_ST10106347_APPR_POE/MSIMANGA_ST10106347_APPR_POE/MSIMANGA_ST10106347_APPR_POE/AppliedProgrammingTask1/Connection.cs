﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace AppliedProgrammingTask1
{
    public class Connection
    {
        public string getConnection = @"Data Source=tcp:motheo.database.windows.net,1433;Initial Catalog=Artists(ice_act221);User Id=msimanga@motheo;Password=Motheo!M";
    }
}
