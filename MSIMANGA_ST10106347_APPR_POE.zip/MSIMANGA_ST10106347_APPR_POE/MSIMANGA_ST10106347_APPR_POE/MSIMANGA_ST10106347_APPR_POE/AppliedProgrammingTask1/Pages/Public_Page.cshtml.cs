using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppliedProgrammingTask1.Pages
{
    public class Public_PageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
